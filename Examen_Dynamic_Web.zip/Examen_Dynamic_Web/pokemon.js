const error = $('.js-error');
error.hide();
console.log('https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js/pikachu');


const Pokemon = class {
    constructor(name, isShiny) {
        this.name = name
        this.isShiny = isShiny
        this.getImages();
    }

    getImages() {

        $.ajax({
                url: 'https://pokeapi.co/api/v2/pokemon/' + this.name,
                dataType: 'json',

                success: function (data) {
                    console.log(data);

                    console.log(data['species']['name']);
                    const $template = $('#pokeTemplate').contents().clone();
                    $template.find('h1').text(data['species']['name'])
                    let damage = $('#damage').val();
                    let hp = $('#hp').val();
                    $template.find('.js-damage').text(damage)
                    $template.find('.js-hp').text(hp)


                    let shiny = $("#shiny").is(":checked");
                    console.log(shiny);
                    if (shiny != true) {



                        let foto = data['sprites']['back_default']
                        $template.find('img:nth-child(2)').attr('src', foto)
                        let fotoo = data['sprites']['front_default']
                        $template.find('img:nth-child(3)').attr('src', fotoo)

                    } else {

                        let foto = data['sprites']['back_shiny']
                        $template.find('img:nth-child(2)').attr('src', foto)
                        let fotoo = data['sprites']['front_shiny']
                        $template.find('img:nth-child(3)').attr('src', fotoo)

                    }

                    $template.appendTo('.js-pokemons')



                }


            })
            .fail(function () {
                alert('fout');
                $('input').val('');
            })

    }




};


 

$('.js-create').on('click', createPokemon)

$('input').keypress(function (event) {
    
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == '13') {
     
        createPokemon()
    }
})
var valueDamage;
var atacker;
    
//$(document).ready(function(){
$('body').on('click', '.card', function () {
    var check=$(this).find('h1').html()
    if ( check== "DEAD" ) {
        alert('Game Over')
        return;
    }
    var victim= $(this).find('h1').html();
    if (atacker==victim) {
        alert('Kan niet dezelefde pokemon aanvallen');
        atacker=null;
        victim=null;
        valueDamage=null;
      return;  
    }
    
    //var click =  $(any).data('click');
    if (!valueDamage|| valueDamage == 0 ){
       valueDamage = $(this).find('.js-damage').html()
       atacker   = $(this).find('h1').html()
  console.log(atacker);
     
    console.log(valueDamage)  
  //  $(any).data('click',click = 1);
  //  console.log(click)
     
    }else{
        var valueHp = $(this).find('.js-hp').html()
        var som = valueHp - valueDamage 
        if (som<=0){
            gameOver($(this))
        }else{
       $(this).find('.js-hp').text(som)
        console.log(valueHp) ;
        console.log(som);
        atacker=null;
        valueDamage=0
    }
       // $(any).data('click',click = 0);  
    } 
       
     
})
 function gameOver(dit){
    dit.find('h1').text('DEAD')
    dit.find('img:nth-child(2)').attr('src','Foto/game-over.jpg').width('150px').height('100px');
    dit.find('img:nth-child(3)').remove();
    dit.find('.js-damage').text('GAMEOVER')
    dit.find('.js-hp').text('GAMEOVER')
    dit.find('.h2-damage').text(' ')
    dit.find('.h2-hp').text(' ')

}
//if (valueDamage!=0) {
 //   $('body').on('click', '.card', function () {

  //      var valueHp = $(this).find('.js-hp').html()
       // $('.card').css("background-color", "yellow");
    //    console.log(valueHp)
         
   // })  
//}
//});

//$('body').on('mouseover', '.card', function () {
  //  check=null;
  //  var check=$(this).find('h1').html()
 // if ( check== "DEAD" ) {
 //   check=null;
  //  $(".card").hover(function(){
  //      $(this).css("background-color", "red");
  //  },function(){
  //   $(this).css("background-color", "white");
 //  })
 //  return;  
//}else{
//    $(".card").hover(function(){
 //       check=null;
    //            $(this).css("background-color", "green");
     //       },function(){
      //       $(this).css("background-color", "white");
    //       })
    //       return;
  //      }
     
//})

$("body").on("mouseenter",'.card', function () {
      check=null;
    var check=$(this).find('h1').html()
 if ( check== "DEAD" ) {
    check=null;
    
       $(this).css("background-color", "red");
 }else{
    $(this).css("background-color", "green");
 }


}).on('mouseleave','.card', function (e) {
    $(this).css("background-color", "white");
})

$('.restart').on('click', function () {

    location.reload(true);

})
 
 
//window.onclick = e => {
  // console.log(e.target);
 // console.log(e.target.tagName);
//} 



//function addValue() {
//   let damage = $('#damage').val();
//   let hp = $('#hp').val();
//   $('js-damage').text('2')
//   console.log(damage)
//  $('js-hp').text('2')
//
//}

function createPokemon() {
    let hp = $('#hp').val();
    let damage = $('#damage').val();
    if (hp==''||damage==''||hp<=0||damage<=0) {
        alert('Juist invullen')
        return;
    }
    let value = $("#pokemon").val();
    let shiny = $("#shiny").is(":checked");
    console.log(value + " " + shiny);
    new Pokemon(value, shiny);
}